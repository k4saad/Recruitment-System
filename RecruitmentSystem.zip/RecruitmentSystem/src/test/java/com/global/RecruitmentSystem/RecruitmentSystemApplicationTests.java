package com.global.RecruitmentSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecruitmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
